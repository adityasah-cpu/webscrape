# 🎓 Using Your Profile (Field of Study)

The Job Finder now lets you **select your degree or field of study**, and it will automatically search for jobs matching that field.

## How It Works

### Step 1: Open the Sidebar
When you start the app (`streamlit run app.py`), look at the **left sidebar**.

### Step 2: Scroll Down to "Your Profile"
Below the source selections, you'll see:
```
2 · Your Profile
```

### Step 3: Select Your Field(s)
Click on **"Your field(s) of study"** and pick from the dropdown list:

**Available Fields:**
- Computer Science / IT
- Cybersecurity
- Data Science
- Web Development
- Machine Learning / AI
- Mobile Development
- Cloud Engineering
- Business Administration
- Finance / Accounting
- Marketing
- Digital Marketing
- HR / People Operations
- Product Management
- UX / UI Design
- Graphic Design
- Content Writing
- Data Analytics
- Business Analytics
- Project Management
- Law
- **Optometry** ← For Centurion University students
- Pharmacy
- Engineering
- Biotechnology

You can select **multiple fields**. For example, if you're doing "Computer Science" with an "AI" focus, select both.

### Step 4: Custom Field (Optional)
If your field isn't in the list, type it in **"Or enter custom field"**:
- Aeronautical Engineering
- Environmental Science
- Psychology
- Biotechnology
- Any other degree name

Separate multiple custom fields with commas: `Field 1, Field 2`

### Step 5: Add Keywords (Optional)
In the **Filters** section below, you can add **additional keywords** to refine your search:
- "python" (programming language)
- "react" (web framework)
- "UI design" (skill)

### Step 6: Click "Fetch jobs"
Once you've selected your field(s) and other sources, click the **"🔍 Fetch jobs"** button.

### Step 7: See Results
After fetching, you'll see:
- 🔎 **Searching for:** Shows all keywords (your field + any you added)
- A table of jobs matching your profile
- Filter further by country, work type, job type, etc.

---

## Examples

### Example 1: "I'm a Cybersecurity major from Centurion University"
1. **Sidebar → Your Profile:**
   - Select: "Cybersecurity"
   - Custom field: (leave empty)

2. **Filters:**
   - Keywords: "security, penetration testing" (optional)
   - Work type: Remote
   - Country: India
   - Job type: Full-time, Internship

3. **Click "Fetch jobs"**
   - App searches for jobs with: "cybersecurity", "security", "penetration testing"

---

### Example 2: "Data Science with Python focus"
1. **Sidebar → Your Profile:**
   - Select: "Data Science"
   - Custom field: (empty)

2. **Filters:**
   - Keywords: "python, machine learning"
   - Work type: Remote
   - Country: India
   - Job type: Internship (to start)

3. **Result:** Jobs matching "data science", "python", "machine learning"

---

### Example 3: "Optometry student looking for any opportunity"
1. **Sidebar → Your Profile:**
   - Select: "Optometry"
   - Custom field: (empty)

2. **Filters:**
   - Keywords: (leave empty)
   - Work type: Remote, Hybrid, Onsite
   - Country: India
   - Job type: Internship, Full-time

3. **Result:** All jobs mentioning "optometry" + any health/medical roles

---

### Example 4: "Uncommon degree not in the list"
1. **Sidebar → Your Profile:**
   - Select: (nothing)
   - Custom field: "Paleobiology, Archaeology"

2. **Filters:**
   - Keywords: "field research, museums"
   - Country: Worldwide
   - Work type: Remote

3. **Result:** Jobs mentioning "paleobiology", "archaeology", "field research", "museums"

---

## How the Search Works

Your **field(s)** are automatically combined with **additional keywords** to search job titles and company names.

```
Profile Fields + Additional Keywords = Search Terms
```

**Example:**
- Profile: "Cybersecurity"
- Keywords: "india, remote"
- **Search for:** "cybersecurity", "india", "remote" (in job title + company name)

---

## Tips

✅ **DO:**
- Select your **primary field** (Computer Science, Business, etc.)
- Use **additional keywords** for specific skills (Python, SQL, marketing, etc.)
- Try different keyword combinations
- Remove filters if "No jobs found"

❌ **DON'T:**
- Leave all filters blank and expect results
- Search for too many keywords at once (results get narrow)
- Forget to click "Fetch jobs" after changing your profile

---

## Still Not Finding Jobs?

1. **Remove the custom field** and use the dropdown
2. **Try fewer keywords** (e.g., just "Cybersecurity", not "Cybersecurity Python Linux")
3. **Change work type** (try "Hybrid" or "Onsite", not just "Remote")
4. **Remove country filter** (select "All countries" or more options)
5. **Enable more sources** (like Adzuna, Unstop, Upwork)
6. **Check Source Status** — if a source shows ❌, it may be temporarily down

---

## Questions?

- Check **README.md** for full documentation
- Look at **QUICK_START.txt** for fast setup
- Experiment! The filters are instant once you've fetched jobs

---

**Happy searching! 🚀**
