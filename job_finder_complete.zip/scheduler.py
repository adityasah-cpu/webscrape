"""
Job scraper scheduler - runs automatically on a schedule.
Fetches new jobs, stores in DB, and sends alerts.

Usage:
    python scheduler.py                              # Run once
    python scheduler.py --daemon                     # Run continuously every N hours
    python scheduler.py --cron                       # Print cron command to set up
"""

import argparse
import json
import os
import sys
import time
from datetime import datetime

import remote_job_scraper as rjs
import db
import alerts as alert_module

# Configuration file
CONFIG_FILE = "scraper_config.json"

# Default config
DEFAULT_CONFIG = {
    "sources": [
        "remotive", "remoteok", "himalayas", "jobicy", "weworkremotely",
        "internshala", "unstop", "firstnaukri", "angellist",
        "devto", "upwork", "toptal"
    ],
    "filters": {
        "work_type": ["Remote", "Hybrid"],  # Remove "Onsite" if only remote
        "countries": ["India"],
        "job_types": ["Full-time", "Internship"],
        "keywords": ["cybersecurity", "python", "data science"],  # Edit as needed
    },
    "alerts": {
        "enabled": False,
        "telegram": None,  # {"bot_token": "...", "chat_id": "..."}
        "email": None,     # {"sender": "...", "password": "...", "recipient": "..."}
        "slack": None,     # {"webhook_url": "..."}
    },
    "schedule": {
        "interval_hours": 8,  # Run every 8 hours
        "send_alert_if_new": True,
        "alert_after_hours": 24,  # Only alert on jobs added in last 24 hours
    }
}


def load_config():
    """Load or create config file."""
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE) as f:
            return json.load(f)
    else:
        with open(CONFIG_FILE, "w") as f:
            json.dump(DEFAULT_CONFIG, f, indent=2)
        print(f"Created {CONFIG_FILE}. Edit it to customize filters and alerts.")
        return DEFAULT_CONFIG


def run_once(config):
    """Fetch jobs once and send alerts."""
    print(f"\n{'='*60}")
    print(f"Job Scraper Run: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*60}\n")
    
    # Initialize DB
    db.init_db()
    
    # Build scraper list
    sources = {s.__name__.replace("scrape_", ""): s for s in rjs.SCRAPERS}
    enabled = [sources[name] for name in config["sources"] if name in sources]
    
    print(f"Enabled sources: {', '.join([s.__name__.replace('scrape_', '') for s in enabled])}")
    
    # Fetch jobs
    all_jobs = []
    for scraper in enabled:
        name = scraper.__name__.replace("scrape_", "")
        print(f"  → {name} ...", end=" ", flush=True)
        try:
            results = scraper()
            print(f"✅ {len(results)} jobs")
            all_jobs.extend(results)
        except Exception as e:
            print(f"❌ {e}")
    
    # Dedupe
    jobs = rjs.dedupe(all_jobs)
    print(f"\nAfter dedup: {len(jobs)} unique jobs")
    
    # Apply filters
    filtered = []
    for j in jobs:
        # Work type
        if config["filters"]["work_type"] and j["work_type"] not in config["filters"]["work_type"]:
            continue
        # Country
        if config["filters"]["countries"]:
            job_countries = set(j["country"].split(";"))
            if not job_countries & set(config["filters"]["countries"]):
                continue
        # Job type
        if config["filters"]["job_types"]:
            job_types = {t.strip() for t in j["job_type"].split(",")}
            if not job_types & set(config["filters"]["job_types"]):
                continue
        # Keywords
        if config["filters"]["keywords"]:
            text = (j["title"] + " " + j["company"]).lower()
            if not any(k.lower() in text for k in config["filters"]["keywords"]):
                continue
        
        filtered.append(j)
    
    print(f"After filters: {len(filtered)} matching jobs")
    
    # Store in DB
    new_count = db.insert_jobs(filtered)
    print(f"New jobs added to DB: {new_count}")
    
    # Send alerts
    if config["alerts"]["enabled"] and new_count > 0:
        alert_jobs = db.get_new_jobs(hours=config["schedule"]["alert_after_hours"])
        if alert_jobs:
            print(f"\nSending alerts for {len(alert_jobs)} new jobs...")
            
            alert_config = {}
            if config["alerts"]["telegram"]:
                alert_config["telegram"] = config["alerts"]["telegram"]
            if config["alerts"]["email"]:
                alert_config["email"] = config["alerts"]["email"]
            if config["alerts"]["slack"]:
                alert_config["slack"] = config["alerts"]["slack"]
            
            if alert_config:
                alert_module.send_alert(alert_jobs, alert_config)
                # Mark as alerted
                for job in alert_jobs:
                    db.mark_alerted(job["id"], "multi", "all")
            else:
                print("  ⚠️  Alerts enabled but no channels configured.")
    
    # Export CSV
    csv_count = db.export_csv("jobs.csv")
    print(f"\nExported to jobs.csv: {csv_count} total jobs")
    
    # Stats
    stats = db.get_stats()
    print(f"\nDatabase stats:")
    print(f"  Total jobs: {stats['total']}")
    print(f"  Sources: {stats['sources']}")
    print(f"  By work type: {stats['by_type']}")
    
    print(f"\n{'='*60}")
    return new_count


def daemon_mode(config):
    """Run continuously on schedule."""
    interval = config["schedule"]["interval_hours"] * 3600
    
    print(f"Starting daemon mode. Running every {config['schedule']['interval_hours']} hours.")
    print("Press Ctrl+C to stop.\n")
    
    try:
        while True:
            run_once(config)
            print(f"\nNext run in {config['schedule']['interval_hours']} hours...")
            time.sleep(interval)
    except KeyboardInterrupt:
        print("\n\nDaemon stopped.")


def print_cron_command(config):
    """Print cron command for scheduling."""
    interval = config["schedule"]["interval_hours"]
    
    # Convert hours to cron (simple approach: every N hours)
    if interval == 1:
        cron = "0 * * * *"
    elif interval == 6:
        cron = "0 0,6,12,18 * * *"
    elif interval == 8:
        cron = "0 0,8,16 * * *"
    elif interval == 12:
        cron = "0 0,12 * * *"
    else:
        cron = "0 */6 * * *"  # Default to every 6 hours
    
    script_path = os.path.abspath(__file__)
    
    print(f"\nTo set up automatic job scraping every {interval} hours, add this to your crontab:\n")
    print(f"crontab -e")
    print(f"\nThen add this line:")
    print(f"{cron} cd {os.path.dirname(script_path)} && source venv/bin/activate && python {script_path} >> scheduler.log 2>&1")
    print(f"\nThis will:")
    print(f"  - Run every {interval} hours")
    print(f"  - Save output to scheduler.log")
    print(f"  - Activate your virtual environment first")
    print(f"\nTo verify it's working:")
    print(f"  tail -f scheduler.log")


def main():
    parser = argparse.ArgumentParser(description="Job scraper scheduler")
    parser.add_argument("--daemon", action="store_true", help="Run continuously")
    parser.add_argument("--cron", action="store_true", help="Print cron setup command")
    parser.add_argument("--config", default=CONFIG_FILE, help="Config file path")
    args = parser.parse_args()
    
    config = load_config()
    
    if args.cron:
        print_cron_command(config)
    elif args.daemon:
        daemon_mode(config)
    else:
        # Run once
        run_once(config)


if __name__ == "__main__":
    main()
