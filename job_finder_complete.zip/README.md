# 🌍 Job Finder for Freshers (India-Focused)

A web scraper that pulls **internships, entry-level jobs, and freelance gigs** from 17+ sources, with filters for work type, country, experience level, and more.

## Quick Start

### 1. Install dependencies (one time)
```bash
cd ~/Desktop/Expts
source venv/bin/activate
pip install requests feedparser streamlit pandas
```

### 2. Run the web UI
```bash
streamlit run app.py
```
Your browser will open to `http://localhost:8501`

### 3. (Optional) Set up Adzuna for India job search
Adzuna lets you search all jobs in India (remote, hybrid, onsite) by keyword.

1. Sign up for free at https://developer.adzuna.com
2. Copy your **App ID** and **App key**
3. In the app, expand **Adzuna settings** and paste the keys

---

## Sources Included

### 🎓 Freshers & Internships (India-focused) — **ENABLED BY DEFAULT**
- **Internshala** — India's largest internship platform. Remote internships, stipends listed.
- **Unstop** — Hackathons → internships → jobs. Fresher-friendly startups.
- **FirstNaukri** — Built for freshers (0–3 years), India-focused.
- **AngelList** — Startup jobs worldwide. Often open to freshers with potential.

### 💻 Remote-only job boards — **ENABLED BY DEFAULT**
- Remotive, RemoteOK, Himalayas, Jobicy, We Work Remotely

### 💼 All jobs (with remote/hybrid/onsite)
- **Adzuna** — Search by country. Covers India, US, UK, Canada, and 15+ others.
- **Arbeitnow** — Europe-wide (Germany, France, Spain, etc.), all job types.

### 🤝 Freelance & Developer
- **Upwork** — Project-based and hourly gigs. Great for building a portfolio.
- **Toptal** — Vetted remote freelancers. Higher pay, stricter quality.
- **Dev.to** — Developer community. Some job listings from startups.

### 🏢 Company career pages
- **Greenhouse, Lever, Ashby** — Hosted ATS platforms. Add company slugs to search specific orgs.

---

## Filtering Tips

### For Internships
1. Leave **Work type** as "Remote" (Internshala is remote-only).
2. Set **Country** to "India".
3. Set **Job type** to "Internship".
4. Search by skills: `python`, `frontend`, `data analytics`, etc.

### For Entry-Level Full-Time Jobs in India
1. Enable **Adzuna** in the sidebar (add free API keys).
2. Filter: **Work type** = "Remote", **Job type** = "Full-time", **Country** = "India".
3. Search by role: `python developer`, `data scientist`, `UI designer`.

### For Freelance Work (Build Portfolio)
1. Enable **Upwork**, **Toptal**, and **Dev.to**.
2. Filter: **Work type** = "Remote", **Job type** = "Freelance".
3. These are worldwide. Great for freshers to build experience + income.

---

## Command Line (No UI)

Run the scraper directly:
```bash
python remote_job_scraper.py                  # fetch all jobs
python remote_job_scraper.py python react     # only jobs with "python" or "react" in title
```

This saves `jobs.csv` with all results.

---

## Degrees & Skills Matching

The scraper doesn't filter by degree, but you can manually match:

**Centurion University (typical courses)**
- Computer Science → Python, Java, Web Dev, Data Science, Full-Stack
- Commerce → Digital Marketing, Finance Analytics, Data Analytics
- Management → Business Analyst, Project Manager, Product Manager
- Engineering → Cloud, DevOps, IoT, Embedded Systems

**Search keywords on the app** to find relevant roles. E.g., search `"data science"` if you did a data science internship.

---

## Troubleshooting

### "No jobs found"
- Try broader filters: remove country, work type, or job type filters.
- Enable more sources in the sidebar.
- Make sure you clicked **Fetch jobs**.

### Source shows ❌ error
- Most APIs are stable. If one fails, others still work.
- Some sources (Upwork, Unstop) may rate-limit if you refresh too fast. Wait a minute and try again.

### Adzuna returns 0 results
- Your API keys may be invalid. Check them on https://developer.adzuna.com.
- Make sure you chose a supported country (India, US, UK, Canada, etc.).

---

## API Keys Needed (Optional)

| Source | Key | Where to get | Required? |
|--------|-----|--------------|-----------|
| **Adzuna** | App ID + Key | https://developer.adzuna.com (free) | No (limits results without it) |
| **Others** | None | — | No |

---

## Example Workflows

### "I just graduated. Find me remote internships."
1. Leave defaults (Internshala, Unstop, FirstNaukri enabled).
2. Set Work type = "Remote", Job type = "Internship", Country = "India".
3. Search: `python`, `web development`, etc.

### "I want freelance projects to build my portfolio."
1. Enable Upwork, Toptal, Dev.to (sidebar).
2. Set Work type = "Remote", Job type = "Freelance".
3. Search your strongest skill.
4. Apply to 5–10 projects with good descriptions of your work.

### "I'm looking for a full-time job in the US, but open to India too."
1. Enable Adzuna (add keys).
2. Set Country = "United States" and "India".
3. Check "Also show remote jobs open Worldwide".
4. Set Job type = "Full-time".
5. Search your target role (e.g., `software engineer`).

---

## Contact & Updates

- **Bug reports or new sources?** Update the Python files or ask for help.
- **Want to add Upwork, GitHub Jobs, or LinkedIn?** They have stricter APIs, but possible.
- **For Centurion University placements:** Ask your placement cell if they list jobs on Internshala or LinkedIn.

---

**Happy job hunting! 🚀**
