# ⚠️ Troubleshooting: Unable to Fetch Jobs

If you see "No jobs found" or errors when fetching, follow these steps.

## Quick Fix (Try First)

```bash
cd ~/Desktop/Expts
source venv/bin/activate
python diagnose.py
```

This will:
- ✅ Check your dependencies
- ✅ Test network connectivity
- ✅ Test each scraper individually
- 📊 Show which sources work and which don't

---

## Common Issues & Solutions

### Issue 1: "No jobs found" in the web UI

**Causes:**
- Job sites are temporarily down
- Your network is rate-limited
- Cookies/session expired
- API changed

**Solutions:**
1. **Run diagnostic first:**
   ```bash
   python diagnose.py
   ```

2. **Check which sources actually work:**
   - The diagnostic shows ✅ or ❌ for each source
   - Use ONLY the working sources in the app

3. **Try with fewer sources:**
   - In sidebar, uncheck all sources
   - Check only 1-2 sources (e.g., just "Internshala")
   - Click "Fetch jobs" again

4. **Wait and retry:**
   - Some sites rate-limit requests
   - Wait 5-10 minutes and try again

5. **Clear browser cache:**
   ```bash
   # Kill and restart the app
   # Press Ctrl+C in terminal
   streamlit run app.py
   ```

---

### Issue 2: "Connection error" or "Timeout"

**Causes:**
- Your internet is slow/down
- Network is blocking job sites
- Firewall blocking requests

**Solutions:**
```bash
# Test your internet
python diagnose.py
```

If network test shows ❌:
- Check WiFi connection
- Try mobile hotspot instead
- Ask your network admin if job boards are blocked

---

### Issue 3: "403 Forbidden" errors

**Causes:**
- Job site blocked your IP (too many requests)
- Blocking bot traffic
- Regional restrictions

**Solutions:**
1. **Wait 10-15 minutes** (IP block is temporary)
2. **Use a different network** (mobile hotspot, different WiFi)
3. **Try from a VPN** (if blocked by region):
   ```bash
   # Install simple VPN or use phone hotspot
   ```
4. **Use only RSS-based sources** (they're usually more permissive):
   - We Work Remotely
   - FirstNaukri
   - Upwork RSS feed

---

### Issue 4: Specific source keeps failing

**Example:** Internshala returns 0 jobs

```bash
python diagnose.py
```

Look for the source in the output:
- ✅ **Working** → Use it, it's fine
- ⚠️ **0 jobs** → Site API changed or no jobs matching
- ❌ **Error** → Site is blocking us or down

**What to do:**
- If ⚠️ or ❌, **disable that source** in the app
- Use the working sources instead
- Try again in a few hours

---

## Manual Testing (Advanced)

### Test a single scraper directly

```bash
python -c "
import remote_job_scraper as rjs
print('Testing Internshala...')
jobs = rjs.scrape_internshala()
print(f'Found: {len(jobs)} jobs')
if jobs:
    print(f'First job: {jobs[0][\"title\"]} @ {jobs[0][\"company\"]}')
"
```

Replace `scrape_internshala` with:
- `scrape_remotive`
- `scrape_upwork`
- `scrape_adzuna`
- `scrape_unstop`
- etc.

### Debug mode (see all errors)

```bash
python -c "
import remote_job_scraper as rjs
import traceback

try:
    jobs = rjs.scrape_internshala()
    print(f'Success: {len(jobs)} jobs')
except Exception as e:
    print(f'Error: {e}')
    traceback.print_exc()
"
```

---

## Working Sources (Most Reliable)

If most sources fail, try these **most reliable** ones:

1. **We Work Remotely** (RSS-based, always works)
2. **Upwork** (RSS feed)
3. **Dev.to** (API usually stable)
4. **AngelList** (startup jobs)

To use only these:
1. In sidebar, **uncheck** all sources
2. Check ONLY: "We Work Remotely", "Upwork", "Dev.to", "AngelList"
3. Click "Fetch jobs"

---

## Fallback: Use Command Line

If the web UI keeps failing, use the scraper directly:

```bash
# Get Python format
python remote_job_scraper.py python data science

# Or use scheduler (which has better error handling)
python scheduler.py
```

Then download `jobs.csv`.

---

## Known Issues

| Site | Issue | Status |
|------|-------|--------|
| Remotive | API blocking bots | Temporary |
| RemoteOK | Rate limit | Temporary |
| LinkedIn | Doesn't allow scraping | Permanent |
| Indeed | Doesn't allow scraping | Permanent |
| Adzuna | Needs API key | Needs setup |
| Internshala | API structure changed | Being fixed |

---

## Next Steps

### If diagnostic shows some sources working:
```bash
# Use the working sources in the app
streamlit run app.py
# Uncheck the failing ones
# Fetch from working sources only
```

### If all sources fail:
```bash
# Wait 10-15 minutes (might be rate-limited)
# Try again: python diagnose.py

# If still failing, try:
# 1. Check internet: ping 8.8.8.8
# 2. Try different network (mobile hotspot)
# 3. Use scheduler instead (better error handling):
python scheduler.py
```

### If one specific source fails:
```bash
# Disable it in the web UI
# Use other sources instead
# Come back to it later
```

---

## Real Example: Debugging Step-by-Step

```
User: "No jobs found in app"

Step 1: Run diagnostic
$ python diagnose.py
Result: Remotive ✅, Internshala ❌, Upwork ⚠️

Step 2: Use only working sources
- Uncheck Internshala
- Keep Remotive checked
- Keep Upwork unchecked (0 jobs)
- Click Fetch

Result: 45 jobs from Remotive only! ✅
```

---

## Still Not Working?

1. **Check the diagnostic output carefully** — note which sources show ✅
2. **Use ONLY those sources** in the app
3. **Be patient** — job sites go down, APIs change
4. **Try again in a few hours** — usually it's temporary

If problems persist after 1 hour:
- Your network may be blocking job sites
- Try from a different network (mobile hotspot)
- Ask your network admin if job boards are restricted

---

## Best Workaround

If web UI fails but you need jobs **right now**:

```bash
python scheduler.py
```

This often works better because:
- Better error handling
- Stores what it CAN fetch
- Doesn't fail completely if one site is down
- Can retry individual sources

---

**Questions?** Run `python diagnose.py` first — it will show you exactly what's working.

🔍 The diagnostic tool is your best friend for troubleshooting!
