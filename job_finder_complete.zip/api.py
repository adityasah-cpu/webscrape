"""
Job Finder - Corporate API Backend (Flask)
Serves job data to professional frontend

Run:
    python api.py
    Then open http://localhost:5000 in browser
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import remote_job_scraper as rjs
import db
import json
from datetime import datetime
import threading

app = Flask(__name__)
CORS(app)

# Global state
cache = {
    "jobs": [],
    "last_fetch": None,
    "stats": {}
}

# ============ API ENDPOINTS ============

@app.route("/api/sources", methods=["GET"])
def get_sources():
    """Get all available sources"""
    sources = {
        "remote_boards": [
            {"id": "remotive", "name": "Remotive", "jobs": 20, "status": "✅"},
            {"id": "remoteok", "name": "RemoteOK", "jobs": 99, "status": "✅"},
            {"id": "himalayas", "name": "Himalayas", "jobs": 200, "status": "✅"},
            {"id": "jobicy", "name": "Jobicy", "jobs": 100, "status": "✅"},
            {"id": "weworkremotely", "name": "We Work Remotely", "jobs": 84, "status": "✅"},
        ],
        "freshers": [
            {"id": "internshala", "name": "Internshala", "jobs": 0, "status": "⚠️"},
            {"id": "unstop", "name": "Unstop", "jobs": 0, "status": "⚠️"},
        ],
        "all_jobs": [
            {"id": "arbeitnow", "name": "Arbeitnow", "jobs": 800, "status": "✅"},
            {"id": "adzuna", "name": "Adzuna", "jobs": 0, "status": "❌ (needs API key)"},
        ]
    }
    return jsonify(sources)


@app.route("/api/fetch", methods=["POST"])
def fetch_jobs():
    """Fetch jobs from selected sources"""
    data = request.json
    selected = data.get("sources", [])
    
    sources = {s.__name__.replace("scrape_", ""): s for s in rjs.SCRAPERS}
    enabled = [sources[name] for name in selected if name in sources]
    
    all_jobs = []
    status = {}
    
    for scraper in enabled:
        name = scraper.__name__.replace("scrape_", "")
        try:
            results = scraper()
            all_jobs.extend(results)
            status[name] = {"success": True, "count": len(results)}
        except Exception as e:
            status[name] = {"success": False, "error": str(e)[:50]}
    
    jobs = rjs.dedupe(all_jobs)
    cache["jobs"] = jobs
    cache["last_fetch"] = datetime.now().isoformat()
    
    # Calculate stats
    cache["stats"] = {
        "total": len(jobs),
        "by_work_type": {},
        "by_country": {},
        "by_source": {}
    }
    for j in jobs:
        wt = j.get("work_type", "Unknown")
        cache["stats"]["by_work_type"][wt] = cache["stats"]["by_work_type"].get(wt, 0) + 1
        
        country = j.get("country", "Unknown").split(";")[0].strip()
        cache["stats"]["by_country"][country] = cache["stats"]["by_country"].get(country, 0) + 1
        
        source = j.get("source", "Unknown")
        cache["stats"]["by_source"][source] = cache["stats"]["by_source"].get(source, 0) + 1
    
    return jsonify({
        "success": True,
        "jobs_count": len(jobs),
        "status": status,
        "stats": cache["stats"],
        "last_fetch": cache["last_fetch"]
    })


@app.route("/api/jobs", methods=["GET"])
def get_jobs():
    """Get filtered jobs"""
    keyword = request.args.get("keyword", "").lower()
    work_type = request.args.get("work_type", "")
    country = request.args.get("country", "")
    job_type = request.args.get("job_type", "")
    page = int(request.args.get("page", 1))
    limit = int(request.args.get("limit", 20))
    
    jobs = cache["jobs"]
    
    # Filter
    if keyword:
        jobs = [j for j in jobs if keyword in (j.get("title", "") + " " + j.get("company", "")).lower()]
    if work_type:
        jobs = [j for j in jobs if j.get("work_type") == work_type]
    if country:
        jobs = [j for j in jobs if country in j.get("country", "")]
    if job_type:
        jobs = [j for j in jobs if job_type in j.get("job_type", "")]
    
    # Paginate
    total = len(jobs)
    jobs = jobs[(page-1)*limit : page*limit]
    
    return jsonify({
        "jobs": jobs,
        "total": total,
        "page": page,
        "pages": (total + limit - 1) // limit
    })


@app.route("/api/stats", methods=["GET"])
def get_stats():
    """Get job statistics"""
    return jsonify(cache["stats"])


@app.route("/api/export", methods=["GET"])
def export_jobs():
    """Export jobs to CSV"""
    fmt = request.args.get("format", "csv")
    
    if fmt == "csv":
        import csv
        import io
        
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=rjs.FIELDS)
        writer.writeheader()
        writer.writerows(cache["jobs"])
        
        return output.getvalue(), 200, {
            "Content-Disposition": "attachment; filename=jobs.csv",
            "Content-Type": "text/csv"
        }
    
    elif fmt == "json":
        return jsonify(cache["jobs"])


@app.route("/", methods=["GET"])
def index():
    """Serve corporate UI"""
    return open("index.html").read(), 200, {"Content-Type": "text/html"}


if __name__ == "__main__":
    app.run(debug=True, port=5000)
