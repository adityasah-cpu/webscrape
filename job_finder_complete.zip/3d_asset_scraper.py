"""
3D Asset & Freelance Job Scraper
---------------------------------
Scrapes contract/freelance work for 3D modelers, artists, game developers.

Sources:
  - Upwork (API)
  - ArtStation Jobs
  - itch.io job board
  - Behance (limited)
  - GameDev.net

Setup:
    pip install requests feedparser
    
Run:
    python 3d_asset_scraper.py
"""

import csv
import os
import re
import time
from datetime import datetime, timezone

import feedparser
import requests

HEADERS = {"User-Agent": "Mozilla/5.0 (3d-asset-scraper; personal use)"}
TIMEOUT = 30
OUTPUT_FILE = "3d_asset_jobs.csv"

# Upwork API (free tier, no key needed for search)
UPWORK_API_KEY = os.getenv("UPWORK_API_KEY", "")

FIELDS = ["source", "title", "company", "work_type", "budget", "duration", 
          "skills", "location", "category", "date", "url"]


def job(source, title, company="", *, work_type="Freelance", budget="", duration="",
        skills="", location="Remote", category="", date="", url=""):
    return {
        "source": source,
        "title": str(title or "").strip(),
        "company": str(company or "").strip(),
        "work_type": work_type,
        "budget": str(budget or "").strip(),
        "duration": str(duration or "").strip(),
        "skills": str(skills or "").strip(),
        "location": str(location or "").strip(),
        "category": str(category or "").strip(),
        "date": str(date or "")[:10],
        "url": str(url or "").strip(),
    }


def get_json(url, **kwargs):
    r = requests.get(url, headers=HEADERS, timeout=TIMEOUT, **kwargs)
    r.raise_for_status()
    return r.json()


def html_to_text(html):
    """Remove HTML tags."""
    return re.sub(r"<[^>]+>", "", str(html or "")).strip()


def extract_skills(text):
    """Extract skill tags from job description."""
    skills = []
    keywords = [
        "3D modeling", "Blender", "Maya", "3ds Max", "ZBrush", "Substance Painter",
        "Texturing", "Rigging", "Animation", "Low-poly", "High-poly",
        "Unreal Engine", "Unity", "Game Development",
        "CAD", "3D printing", "Rhino", "SolidWorks",
        "Lighting", "Rendering", "VFX", "Photogrammetry",
        "UV mapping", "Shader", "HLSL", "GLSL",
    ]
    text = (text or "").lower()
    for skill in keywords:
        if skill.lower() in text:
            skills.append(skill)
    return ", ".join(skills[:5])  # Top 5 skills


def extract_budget(text):
    """Extract budget from job description."""
    # Look for patterns like $500-1000, $50/hr, $1000 fixed
    patterns = [
        r"\$[\d,]+\s*-\s*\$?[\d,]+",  # $500-1000
        r"\$[\d,]+\s*/\s*(?:hr|hour)",  # $50/hr
        r"\$[\d,]+\s*(?:fixed|flat)?",  # $1000 fixed
    ]
    text = str(text or "")
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            return match.group(0)
    return ""


# ============ UPWORK ============

def scrape_upwork():
    """Upwork: freelance 3D/game dev jobs (RSS feed)."""
    jobs = []
    # Upwork RSS feed for 3D jobs (approximate search)
    feeds = [
        "https://www.upwork.com/ab/feed/jobs/rss?q=3d+modeling+remote",
        "https://www.upwork.com/ab/feed/jobs/rss?q=game+development+freelance",
        "https://www.upwork.com/ab/feed/jobs/rss?q=blender+3d+artist",
    ]
    
    for feed_url in feeds:
        try:
            feed = feedparser.parse(feed_url)
            for entry in feed.entries[:30]:
                title = entry.get("title", "")
                description = entry.get("summary", "")
                date = ""
                if entry.get("published_parsed"):
                    date = time.strftime("%Y-%m-%d", entry.published_parsed)
                
                budget = extract_budget(description)
                skills = extract_skills(title + " " + description)
                
                jobs.append(job("Upwork", title,
                              work_type="Freelance",
                              budget=budget,
                              duration="Project-based",
                              skills=skills,
                              location="Remote",
                              category="3D Art / Game Dev",
                              date=date,
                              url=entry.get("link", "")))
            time.sleep(1)
        except Exception as e:
            print(f"  Upwork feed error: {e}")
    
    return jobs


# ============ ARTSTATION ============

def scrape_artstation():
    """ArtStation Jobs: artists, 3D modelers, concept artists."""
    jobs = []
    try:
        # ArtStation jobs API (public, no auth needed)
        url = "https://www.artstation.com/api/v2/search/jobs"
        params = {
            "q": "3D modeling",
            "direction": "desc",
            "sort": "published_at",
            "page": 1,
            "per_page": 50,
        }
        
        data = get_json(url, params=params)
        for j in data.get("data", []):
            skills_list = [t.get("name", "") for t in j.get("tags", [])[:5]]
            
            jobs.append(job("ArtStation", j.get("title"),
                          company=j.get("client", {}).get("name", ""),
                          work_type="Freelance" if j.get("project_based") else "Contract",
                          budget=j.get("budget_type", ""),
                          duration=j.get("duration", ""),
                          skills=", ".join(skills_list),
                          location=j.get("location", "Remote"),
                          category="3D Art",
                          date=j.get("published_at", "")[:10],
                          url=f"https://www.artstation.com/jobs/{j.get('slug')}"
                          if j.get("slug") else ""))
        time.sleep(1)
    except Exception as e:
        print(f"  ArtStation error: {e}")
    
    return jobs


# ============ ITCH.IO ============

def scrape_itchio():
    """itch.io: indie game dev, 3D asset jobs."""
    jobs = []
    try:
        # itch.io job board (public)
        feed = feedparser.parse("https://itch.io/jobs/feed")
        for entry in feed.entries[:50]:
            title = entry.get("title", "")
            content = html_to_text(entry.get("summary", ""))
            date = ""
            if entry.get("published_parsed"):
                date = time.strftime("%Y-%m-%d", entry.published_parsed)
            
            # Detect if it's 3D/art related
            if any(keyword in title.lower() + content.lower() 
                   for keyword in ["3d", "art", "model", "texture", "animation", "blender", "unity", "unreal"]):
                budget = extract_budget(content)
                skills = extract_skills(title + " " + content)
                
                jobs.append(job("itch.io", title,
                              work_type="Freelance",
                              budget=budget,
                              duration="Project-based",
                              skills=skills,
                              location="Remote",
                              category="Game Dev / 3D",
                              date=date,
                              url=entry.get("link", "")))
        time.sleep(1)
    except Exception as e:
        print(f"  itch.io error: {e}")
    
    return jobs


# ============ BEHANCE ============

def scrape_behance():
    """Behance: creative jobs (limited, mostly RSS)."""
    jobs = []
    try:
        feed = feedparser.parse("https://www.behance.net/api/v2/search/jobs?rss=1")
        for entry in feed.entries[:30]:
            title = entry.get("title", "")
            date = ""
            if entry.get("published_parsed"):
                date = time.strftime("%Y-%m-%d", entry.published_parsed)
            
            jobs.append(job("Behance", title,
                          work_type="Freelance",
                          duration="Project-based",
                          location="Remote",
                          category="Creative / Design",
                          date=date,
                          url=entry.get("link", "")))
        time.sleep(1)
    except Exception as e:
        print(f"  Behance error: {e}")
    
    return jobs


# ============ GAMEDEV.NET ============

def scrape_gamedevnet():
    """GameDev.net: game dev job board."""
    jobs = []
    try:
        # GameDev.net job board (web scrape, limited)
        feed = feedparser.parse("https://www.gamedev.net/jobs/")
        for entry in feed.entries[:40]:
            title = entry.get("title", "")
            date = ""
            if entry.get("published_parsed"):
                date = time.strftime("%Y-%m-%d", entry.published_parsed)
            
            if any(k in title.lower() for k in ["3d", "art", "model", "programmer"]):
                jobs.append(job("GameDev.net", title,
                              work_type="Full-time / Freelance",
                              location="Remote / Various",
                              category="Game Development",
                              date=date,
                              url=entry.get("link", "")))
        time.sleep(1)
    except Exception as e:
        print(f"  GameDev.net error: {e}")
    
    return jobs


# ============ CGTRADER / TURBOSQUID ============

def scrape_3d_marketplaces():
    """TurboSquid, CGTrader: 3D asset sales (freelance work)."""
    jobs = []
    try:
        # These are mostly asset sales, not gigs, but some list freelance work
        # For now, check RSS or public job listings
        
        # TurboSquid careers
        feed = feedparser.parse("https://www.turbosquid.com/Search/3D-Models/jobs")
        # This typically won't have RSS, but worth checking
        
    except Exception as e:
        print(f"  3D Marketplace error: {e}")
    
    return jobs


SCRAPERS = [
    scrape_upwork,
    scrape_artstation,
    scrape_itchio,
    scrape_behance,
    scrape_gamedevnet,
]


# ============ MAIN ============

def dedupe(jobs):
    """Remove duplicate jobs."""
    seen, unique = set(), []
    for j in jobs:
        if not j["title"]:
            continue
        key = (j["title"].lower(), j["company"].lower(), j["url"])
        if key not in seen:
            seen.add(key)
            unique.append(j)
    return unique


def filter_3d_jobs(jobs, keywords=None):
    """Filter for 3D/game dev relevant jobs."""
    if keywords is None:
        keywords = [
            "3d", "blender", "maya", "unreal", "unity", "game",
            "model", "texture", "rigging", "animation", "art",
            "rendering", "shader", "asset", "vfx"
        ]
    
    filtered = []
    for j in jobs:
        text = (j["title"] + " " + j["company"] + " " + j["skills"]).lower()
        if any(k in text for k in keywords):
            filtered.append(j)
    
    return filtered


def main():
    all_jobs = []
    
    print("3D Asset & Freelance Job Scraper")
    print("=" * 50)
    
    for scraper in SCRAPERS:
        name = scraper.__name__.replace("scrape_", "").replace("_", " ").title()
        print(f"→ {name} ...", end=" ", flush=True)
        try:
            results = scraper()
            print(f"✅ {len(results)} jobs")
            all_jobs.extend(results)
        except Exception as e:
            print(f"❌ {e}")
    
    jobs = dedupe(all_jobs)
    print(f"\nAfter dedup: {len(jobs)} unique jobs")
    
    # Filter for 3D/game dev
    filtered = filter_3d_jobs(jobs)
    print(f"3D/Game dev relevant: {len(filtered)} jobs")
    
    # Sort by date
    filtered.sort(key=lambda j: j["date"], reverse=True)
    
    # Save to CSV
    with open(OUTPUT_FILE, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(filtered)
    
    print(f"\nSaved to {OUTPUT_FILE}")
    
    # Show summary
    by_source = {}
    for j in filtered:
        by_source[j["source"]] = by_source.get(j["source"], 0) + 1
    
    print(f"\nBy source:")
    for source, count in sorted(by_source.items(), key=lambda x: -x[1]):
        print(f"  {source}: {count}")


if __name__ == "__main__":
    main()
