# 🚀 Complete Job Finder System - Overview

Two integrated systems for finding jobs:
1. **Manual UI** (freshers in India) - Search when you want
2. **Automated Scheduler** (both freshers + 3D assets) - Run on schedule, get alerts

---

## System 1: Manual Web UI (app.py)

**Best for:** Interactive browsing, trying different filters, quick job search

### Files
- `app.py` — Streamlit web interface
- `remote_job_scraper.py` — 17 job scrapers
- `jobs.csv` — Results (exported)

### Workflow
```
1. streamlit run app.py
2. Select sources in sidebar
3. Choose your field (Cybersecurity, Optometry, etc.)
4. Click "Fetch jobs"
5. Filter results (country, work type, keywords)
6. Click on jobs or download CSV
```

### 17 Sources
- Remote boards: Remotive, RemoteOK, Himalayas, Jobicy, We Work Remotely
- Freshers (India): Internshala, Unstop, FirstNaukri, AngelList
- Developer: Dev.to, Upwork, Toptal
- All jobs: Arbeitnow, Adzuna
- Company pages: Greenhouse, Lever, Ashby

### When to use
- ✅ You want to search right now
- ✅ You want to try different filters
- ✅ You want to see jobs before applying
- ❌ You want automated daily alerts
- ❌ You want historical job data

---

## System 2: Automated Scheduler (scheduler.py)

**Best for:** Daily/hourly automated job scraping, building a job database, getting alerts

### Files
- `scheduler.py` — Scheduler + runner
- `db.py` — SQLite database
- `alerts.py` — Telegram/Email/Slack
- `scraper_config.json` — Configuration
- `jobs.db` — Database (auto-created)
- `scheduler.log` — Log file (when running via cron)

### Workflow
```
1. python scheduler.py
   → Creates scraper_config.json
2. Edit scraper_config.json
   → Set sources, filters, alerts
3. python scheduler.py
   → Runs once, stores in jobs.db, sends alert
4. python scheduler.py --cron
   → Get cron command
5. crontab -e
   → Add cron line to run every 6/8/12 hours
6. Receive Telegram/Email alerts when new jobs found
```

### Modes

**Run once:**
```bash
python scheduler.py
```

**Daemon (continuous, for testing):**
```bash
python scheduler.py --daemon
```

**Print cron setup:**
```bash
python scheduler.py --cron
```

### Database
Jobs stored in `jobs.db` (SQLite):
- Never lose job data
- Can search/filter without re-scraping
- Export to CSV anytime

### Alerts
- **Telegram** — Instant notifications on phone (recommended)
- **Email** — Daily/hourly digest
- **Slack** — Team notifications

### When to use
- ✅ You want daily automated job search
- ✅ You want a growing database of jobs
- ✅ You want instant alerts (Telegram)
- ✅ You want to track jobs over time
- ❌ You want interactive filtering (use app.py instead)

---

## System 3: 3D Asset / Freelance Scraper (3d_asset_scraper.py)

**Best for:** Game dev, 3D artists, contract work

### Files
- `3d_asset_scraper.py` — Scraper for 3D jobs
- `3d_asset_jobs.csv` — Results

### Workflow
```
1. python 3d_asset_scraper.py
2. Edit scraper to customize keywords
3. Download 3d_asset_jobs.csv
```

### Sources
- Upwork (3D/game dev jobs)
- ArtStation Jobs
- itch.io job board
- GameDev.net
- Behance (creative)

### When to use
- ✅ You're a 3D artist/modeler
- ✅ You want freelance contract work
- ✅ You're into game development
- ❌ You're looking for full-time jobs in India
- ❌ You want freshers/internships

---

## Quick Decision Matrix

| Situation | System |
|-----------|--------|
| "I want to search right now" | **app.py** |
| "I want daily automated alerts on Telegram" | **scheduler.py** |
| "I want to build a job database over time" | **scheduler.py** |
| "I'm a 3D artist looking for contracts" | **3d_asset_scraper.py** |
| "I want to try 10 different filter combinations" | **app.py** |
| "I want my roommate to get alerts too" | **scheduler.py** + Slack/Telegram |

---

## Full Setup (Integrated)

**Goal:** Get daily job alerts + manual search capability

### Step 1: Set up database + scheduler
```bash
python scheduler.py
# Creates scraper_config.json
```

### Step 2: Configure
Edit `scraper_config.json`:
```json
{
  "sources": ["internshala", "unstop", "firstnaukri", ...],
  "filters": {
    "keywords": ["cybersecurity", "python"],
    "countries": ["India"],
    "job_types": ["Full-time", "Internship"]
  },
  "alerts": {
    "enabled": true,
    "telegram": {
      "bot_token": "YOUR_TOKEN",
      "chat_id": "YOUR_CHAT_ID"
    }
  },
  "schedule": {
    "interval_hours": 8
  }
}
```

### Step 3: Set up cron
```bash
python scheduler.py --cron
# Copy the output line and:
crontab -e
# Paste the line
```

### Step 4: Test
```bash
python scheduler.py
# Check Telegram for alert
tail -f scheduler.log
```

### Step 5: Manual search (optional)
```bash
# Can still use the web UI anytime
streamlit run app.py
```

### Result
- ✅ Automatic scraping every 8 hours
- ✅ Jobs stored in `jobs.db`
- ✅ Telegram alerts for new jobs
- ✅ Manual web UI for interactive search
- ✅ CSV exports whenever you want

---

## File Structure

```
Expts/
├── app.py                        # Web UI
├── remote_job_scraper.py         # 17 scrapers
├── db.py                         # Database
├── alerts.py                     # Alerting
├── scheduler.py                  # Scheduler
├── 3d_asset_scraper.py          # 3D scraper
├── scraper_config.json           # Config (auto-generated)
├── scraper_config_example.json   # Example config
├── jobs.db                       # Database (auto-created)
├── jobs.csv                      # CSV export (auto-created)
├── 3d_asset_jobs.csv            # 3D jobs export
├── scheduler.log                 # Cron log (auto-created)
├── venv/                         # Virtual environment
├── AUTOMATION_GUIDE.md           # Scheduler setup guide
├── PROFILE_GUIDE.md              # Profile feature guide
├── EXAMPLES.txt                  # Visual examples
├── README.md                     # General readme
└── QUICK_START.txt              # Quick start guide
```

---

## Key Features

### System 1 (app.py)
- 17 job sources
- Real-time filtering
- Multi-field search (your degree + keywords)
- Work type, country, job type filters
- Download CSV
- No database/storage

### System 2 (scheduler.py)
- Automated scheduling (cron)
- SQLite database persistence
- Deduplication (no duplicate alerts)
- Multi-channel alerts (Telegram, Email, Slack)
- Search stored jobs anytime
- Track jobs over time
- CSV export

### System 3 (3d_asset_scraper.py)
- 5 3D/game dev sources
- Skill extraction
- Budget detection
- One-time or scheduled runs

---

## Common Workflows

### Workflow A: Fresh Start (Freshers in India)
```bash
# 1. First time: explore with web UI
streamlit run app.py
# Find what sources + keywords work best

# 2. Then: automate with alerts
python scheduler.py
# Edit scraper_config.json with same settings
python scheduler.py --cron
crontab -e
# Add the line

# 3. Get alerts on Telegram every 8 hours
# Download jobs.csv weekly
```

### Workflow B: Historical Data (Researcher)
```bash
# 1. Run scheduler 2-3 times per day for a week
python scheduler.py --daemon
# Builds up jobs.db with 100+ jobs

# 2. After a week, analyze
python -c "import db; print(db.get_stats())"

# 3. Export and analyze
python -c "import db; db.export_csv('analysis.csv')"

# 4. Use Excel/Python to find patterns
# E.g., average salary, most common skills, etc.
```

### Workflow C: Team Sharing (University Group)
```bash
# 1. Set up Slack webhook
python scheduler.py
# Edit scraper_config.json with Slack webhook

# 2. Run on shared server/always-on PC
python scheduler.py --daemon

# 3. Entire team gets alerts in shared Slack channel
# No need to ask "did you see the new Internshala jobs?"
```

### Workflow D: 3D Artist
```bash
# 1. Find contracts
python 3d_asset_scraper.py
# Opens 3d_asset_jobs.csv

# 2. (Optional) Add to scheduler
# Edit scraper_config.json to prioritize ArtStation + itch.io
python scheduler.py

# 3. Get alerts for new 3D/game dev projects
```

---

## Migration Path

If you start with the **web UI** and later want **automation**:

1. Find your optimal filters in `app.py`
2. Create `scraper_config.json` with those exact settings
3. Run `scheduler.py` with the config
4. No need to delete or recreate anything
5. Both systems can run in parallel

---

## Performance Notes

- **Web UI (app.py):** Fetches fresh every time, takes 1-2 minutes, no storage
- **Scheduler (scheduler.py):** Stores everything, dedupes, alert logic is instant
- **3D Scraper (3d_asset_scraper.py):** ~30 seconds, smaller job pool

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| "I don't know where to start" | Read **QUICK_START.txt** |
| "How do I use the profile feature?" | Read **PROFILE_GUIDE.md** |
| "How do I set up alerts?" | Read **AUTOMATION_GUIDE.md** |
| "I want to see examples" | Check **EXAMPLES.txt** |
| "Scraper fails on a source" | Check **Source status** in app |
| "Database is too large" | Delete `jobs.db`, restart from scratch |
| "Cron doesn't run" | Check `scheduler.log`, verify path |

---

## What's Next?

- ✅ **Short term:** Use web UI to find jobs this week
- ✅ **Medium term:** Set up scheduler for daily alerts
- ✅ **Long term:** Build database, analyze trends, share with team
- ✅ **Optional:** Set up 3D scraper if interested in freelance

---

**Ready to go? Start with:** `streamlit run app.py` 🚀
