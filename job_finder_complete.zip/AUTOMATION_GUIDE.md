# 🤖 Automation Guide - Scheduled Job Scraping & Alerts

Run job scrapers **automatically** on a schedule and get notified via **Telegram, Email, or Slack**.

## Quick Start

### 1. Install dependencies
```bash
cd ~/Desktop/Expts
source venv/bin/activate
pip install requests feedparser schedule python-telegram-bot
```

### 2. Create config file
```bash
python scheduler.py
```
This creates `scraper_config.json`. Edit it to:
- Choose which sources to scrape
- Set filters (country, work type, keywords)
- Enable alerts (Telegram, Email, Slack)
- Set schedule interval

### 3. Set up alerts (optional)

#### **Telegram (Recommended - Easiest)**

1. Open Telegram and search for `@BotFather`
2. Send `/newbot`
3. Follow the prompts. You'll get a **Bot Token** like: `123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11`
4. Search for `@userinfobot` and send `/start` → get your **Chat ID** (a number)
5. Edit `scraper_config.json`:
```json
"alerts": {
  "enabled": true,
  "telegram": {
    "bot_token": "123456:ABC-DEF1234...",
    "chat_id": "999999"
  }
}
```

6. Test: `python scheduler.py` (you should get a Telegram message)

#### **Email (Gmail)**

1. Enable 2-factor authentication on your Gmail
2. Go to https://myaccount.google.com/apppasswords
3. Select "Mail" and "Windows Computer" → get **App Password** (16 chars)
4. Edit `scraper_config.json`:
```json
"alerts": {
  "enabled": true,
  "email": {
    "sender": "yourname@gmail.com",
    "password": "xxxx xxxx xxxx xxxx",  # 16-char app password
    "recipient": "yourname@gmail.com"
  }
}
```

5. Test: `python scheduler.py`

#### **Slack**

1. Create a Slack workspace (free) or use existing
2. Go to https://api.slack.com/messaging/webhooks
3. Click "Create New App" → "From scratch"
4. Give it a name, pick your workspace
5. Go to "Incoming Webhooks" → toggle "On"
6. Click "Add New Webhook to Workspace" → select a channel
7. Copy the **Webhook URL**
8. Edit `scraper_config.json`:
```json
"alerts": {
  "enabled": true,
  "slack": {
    "webhook_url": "https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXX"
  }
}
```

9. Test: `python scheduler.py`

---

## Running the Scraper

### **One-time run**
```bash
python scheduler.py
```
Fetches jobs, stores in DB, exports to CSV, and sends alert (if new jobs found).

### **Continuous daemon mode** (for testing)
```bash
python scheduler.py --daemon
```
Runs forever, fetching every N hours (set in config). Stop with `Ctrl+C`.

### **Set up cron job** (automatic, runs in background)
```bash
python scheduler.py --cron
```
Prints the exact cron command to add. Copy and run:
```bash
crontab -e
```

Then paste:
```
0 0,8,16 * * * cd ~/Desktop/Expts && source venv/bin/activate && python scheduler.py >> scheduler.log 2>&1
```

This runs the scraper every 8 hours (at midnight, 8am, 4pm).

---

## Configuration File (`scraper_config.json`)

### Example: Cybersecurity freshers in India

```json
{
  "sources": [
    "remotive",
    "remoteok",
    "himalayas",
    "jobicy",
    "weworkremotely",
    "internshala",
    "unstop",
    "firstnaukri",
    "angellist"
  ],
  "filters": {
    "work_type": ["Remote", "Hybrid"],
    "countries": ["India"],
    "job_types": ["Full-time", "Internship"],
    "keywords": [
      "cybersecurity",
      "security",
      "pentesting",
      "SOC",
      "information security"
    ]
  },
  "alerts": {
    "enabled": true,
    "telegram": {
      "bot_token": "YOUR_BOT_TOKEN",
      "chat_id": "YOUR_CHAT_ID"
    },
    "email": null,
    "slack": null
  },
  "schedule": {
    "interval_hours": 8,
    "send_alert_if_new": true,
    "alert_after_hours": 24
  }
}
```

### Example: 3D Asset / Freelance Work

```json
{
  "sources": [],  # Leave empty, use 3d_asset_scraper.py instead
  "filters": {
    "work_type": ["Freelance"],
    "countries": ["Worldwide"],
    "job_types": ["Project-based"],
    "keywords": [
      "3D modeling",
      "Blender",
      "Maya",
      "texturing",
      "game development",
      "Unity",
      "Unreal"
    ]
  },
  "alerts": {
    "enabled": true,
    "telegram": {...},
    "email": null,
    "slack": null
  },
  "schedule": {
    "interval_hours": 6,
    "send_alert_if_new": true,
    "alert_after_hours": 48
  }
}
```

---

## Database Management

### View stored jobs
```bash
python -c "import db; print(db.get_stats())"
```

### Search jobs in database
```bash
python -c "
import db
jobs = db.get_jobs_by_filter(work_type='Remote', country='India', keyword='python')
for j in jobs[:5]:
    print(f\"{j['title']} @ {j['company']}\")
"
```

### Export to CSV
```bash
python -c "import db; db.export_csv('my_jobs.csv'); print('Exported!')"
```

### Reset database
```bash
rm jobs.db
python -c "import db; db.init_db()"
```

---

## Workflow Example

### Day 1: Set up automation for freshers in India
```bash
# 1. Edit scraper_config.json with:
#    - Sources: Internshala, Unstop, FirstNaukri, etc.
#    - Filters: India, Remote, Full-time + Internship, keywords: "cybersecurity"
#    - Alerts: Telegram enabled

# 2. Test once
python scheduler.py

# 3. Check Telegram for alert

# 4. Set up cron to run every 8 hours
python scheduler.py --cron
crontab -e
# paste the command
```

### Day 7: Check results
```bash
# View what's in the database
python -c "
import db
stats = db.get_stats()
print(f\"Total jobs collected: {stats['total']}\")
print(f\"By work type: {stats['by_type']}\")
"

# Download all jobs
python -c "import db; db.export_csv('cybersecurity_jobs.csv'); print('Saved!')"
```

---

## Monitoring the Scheduler

### View scheduler log
```bash
tail -f scheduler.log
```

### View recent runs
```bash
tail -20 scheduler.log
```

### Check if cron is running
```bash
crontab -l
```

### Stop cron
```bash
crontab -r
```

---

## Troubleshooting

### Q: "ModuleNotFoundError: No module named 'requests'"
**A:** Run `pip install requests feedparser`

### Q: "Telegram alert not sending"
**A:**
- Verify bot token is correct (check with @BotFather)
- Verify chat ID is correct (check with @userinfobot)
- Test manually: `python -c "from alerts import send_telegram; send_telegram('TOKEN', 'CHAT_ID', 'Test')"`

### Q: "Email not sending"
**A:**
- Use **App Password**, not regular Gmail password
- Enable 2FA first at https://myaccount.google.com/security
- Try with a different recipient email (some spam filters block)

### Q: "Cron job never runs"
**A:**
- Check `scheduler.log` exists: `ls -la scheduler.log`
- Verify path is absolute: `which python`
- Test manually: `cd ~/Desktop/Expts && source venv/bin/activate && python scheduler.py`
- Restart cron: `sudo systemctl restart cron`

### Q: "Getting too many/too few jobs"
**A:**
- Adjust keywords in `scraper_config.json`
- Try fewer keywords (too many = too narrow)
- Disable country filter to see all jobs
- Increase or decrease job_types

---

## Advanced: Using 3D Asset Scraper

For freelance 3D modeling work, use the separate scraper:

```bash
python 3d_asset_scraper.py
```

This scrapes **Upwork, ArtStation, itch.io, GameDev.net** for 3D/game dev contracts.

Output: `3d_asset_jobs.csv`

You can integrate this into the scheduler by creating a separate config and running it on a different schedule.

---

## Files

| File | Purpose |
|------|---------|
| `scheduler.py` | Main scheduler (run once or daemon) |
| `db.py` | SQLite database for job storage |
| `alerts.py` | Telegram, Email, Slack alerting |
| `scraper_config.json` | Configuration (edit this!) |
| `jobs.db` | SQLite database (auto-created) |
| `jobs.csv` | Exported jobs (auto-created) |
| `scheduler.log` | Cron job log (auto-created) |
| `3d_asset_scraper.py` | Separate scraper for 3D/freelance |
| `3d_asset_jobs.csv` | 3D job results |

---

## Next Steps

1. ✅ Set up `scheduler.py` with alerts
2. ✅ Run `python scheduler.py --cron` and add to crontab
3. ✅ Check Telegram/Email for daily job alerts
4. ✅ (Optional) Run `python 3d_asset_scraper.py` for 3D work
5. ✅ Download `jobs.csv` when ready to apply

---

**Happy automated job hunting! 🚀**
