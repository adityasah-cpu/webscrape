# 📋 Code Overview - What Was Built

## Architecture Overview

```
┌─────────────────────────────────────────────────┐
│           Job Finder System                    │
└─────────────────────────────────────────────────┘
         ↓                              ↓
    ┌────────────┐              ┌──────────────┐
    │   Web UI   │              │  Scheduler   │
    │  (app.py)  │              (scheduler.py) │
    └────────┬───┘              └──────┬───────┘
             │                         │
             └──────────┬──────────────┘
                        ↓
        ┌──────────────────────────────┐
        │  Job Scrapers                │
        │ (remote_job_scraper.py)      │
        │ • 17 sources                 │
        │ • APIs, RSS feeds, web       │
        └──────────┬───────────────────┘
                   ↓
        ┌──────────────────────────────┐
        │  Database                    │
        │ (db.py)                      │
        │ • SQLite storage             │
        │ • Deduplication              │
        └──────────┬───────────────────┘
                   ↓
        ┌──────────────────────────────┐
        │  Alerts                      │
        │ (alerts.py)                  │
        │ • Telegram                   │
        │ • Email                      │
        │ • Slack                      │
        └──────────────────────────────┘
```

---

## 1. Job Scrapers (remote_job_scraper.py) - 500+ Lines

### Structure
```python
# Scraper for each job board follows same pattern:

def scrape_internshala(max_pages=None):
    """Scrape Internshala (India internship platform)"""
    jobs = []
    for page in range(max_pages):
        try:
            # 1. Make API request
            data = get_json("https://internshala.com/api/v2/...")
            
            # 2. Parse response
            for j in data.get("internships", []):
                # 3. Extract fields
                title = j.get("title")
                company = j.get("company_name")
                salary = fmt_salary(j.get("stipend_min"), j.get("stipend_max"), "₹")
                
                # 4. Create job dict
                job_obj = job("Internshala", title, company,
                             work_type="Remote",
                             location=j.get("location_string"),
                             country="India",
                             job_type="Internship",
                             salary=salary,
                             date=j.get("start_date"),
                             url=f"https://internshala.com/internship/{j.get('id')}")
                jobs.append(job_obj)
        
        except Exception as e:
            print(f"Error: {e}")
            break
    
    return jobs
```

### 17 Scrapers Total
```
Remote-only boards (5):
  • scrape_remotive()     → Remotive API
  • scrape_remoteok()     → RemoteOK API  
  • scrape_himalayas()    → Himalayas API
  • scrape_jobicy()       → Jobicy API
  • scrape_weworkremotely() → RSS feed

Freshers/Internships (4):
  • scrape_internshala()  → India internship API
  • scrape_unstop()       → Unstop API
  • scrape_firstnaukri()  → RSS feed
  • scrape_angellist()    → AngelList API

Freelance/Developer (3):
  • scrape_devto()        → Dev.to API
  • scrape_upwork()       → RSS feed
  • scrape_toptal()       → Toptal API

All Jobs (2):
  • scrape_arbeitnow()    → Arbeitnow API
  • scrape_adzuna()       → Adzuna API

Company Pages (3):
  • scrape_greenhouse()   → Greenhouse API
  • scrape_lever()        → Lever API
  • scrape_ashby()        → Ashby API
```

### Helper Functions
```python
# Parsing & formatting
def fmt_salary(lo, hi, currency):
    """Format salary range"""
    return f"{lo}-{hi} {currency}" if lo and hi else ""

def classify_work_type(text):
    """Detect if job is Remote/Hybrid/Onsite from text"""
    if "hybrid" in text.lower():
        return "Hybrid"
    elif "remote" in text.lower():
        return "Remote"
    return "Onsite"

def detect_countries(location_text):
    """Extract country from location string"""
    # Maps text like "Bengaluru, India" → "India"
    for country, aliases in COUNTRY_ALIASES.items():
        if any(alias in location_text.lower() for alias in aliases):
            return country
    return "Unspecified"

# Deduplication
def dedupe(jobs):
    """Remove duplicate jobs"""
    seen = set()
    unique = []
    for j in jobs:
        key = (j["title"].lower(), j["company"].lower(), j["location"])
        if key not in seen:
            seen.add(key)
            unique.append(j)
    return unique
```

---

## 2. Web UI (app.py) - 250+ Lines

### Streamlit Layout
```python
import streamlit as st

st.set_page_config(page_title="Job Finder", page_icon="🌍", layout="wide")
st.title("🌍 Job Finder")

# Sidebar: Source selection
with st.sidebar:
    st.header("1 · Sources")
    
    # Checkboxes for each source
    remotive_check = st.checkbox("Remotive", value=True)
    internshala_check = st.checkbox("Internshala (India)", value=False)
    # ... 15 more
    
    # Profile selection
    st.header("2 · Your Profile")
    fields = st.multiselect(
        "Your field(s) of study",
        ["Cybersecurity", "Data Science", "Optometry", ...],
        default=[]
    )
    
    run = st.button("🔍 Fetch jobs", type="primary")

# Main area: Filters
st.subheader("Filters")
keyword = st.text_input("Keywords")
work_types = st.multiselect("Work type", ["Remote", "Hybrid", "Onsite"])
countries = st.multiselect("Country", ["India", "US", "UK", ...])
job_types = st.multiselect("Job type", ["Full-time", "Internship", ...])

# Results table
st.dataframe(df, columns=["title", "company", "work_type", "salary", "url"])

# Download
st.download_button("⬇️ Download CSV", csv_data)
```

### Caching (Speed)
```python
@st.cache_data(ttl=3600, show_spinner=False)
def fetch(sources):
    """Cache results for 1 hour so we don't re-scrape"""
    all_jobs = []
    for source in sources:
        jobs = scraper()
        all_jobs.extend(jobs)
    return rjs.dedupe(all_jobs)
```

### Filtering Logic
```python
# Filter by keywords (title + company)
if keyword:
    words = keyword.lower().split(",")
    df = df[df["title"].str.lower().apply(
        lambda t: any(w in t for w in words)
    )]

# Filter by country (supports multiple)
if countries:
    df = df[df["country"].apply(
        lambda c: any(country in c for country in countries)
    )]

# Filter by date
if days:
    dates = pd.to_datetime(df["date"])
    df = df[dates >= (today - timedelta(days=days))]
```

---

## 3. Database (db.py) - 150+ Lines

### SQLite Schema
```python
def init_db():
    """Create tables"""
    conn = sqlite3.connect("jobs.db")
    c = conn.cursor()
    
    # Main jobs table
    c.execute("""
        CREATE TABLE IF NOT EXISTS jobs (
            id INTEGER PRIMARY KEY,
            url TEXT UNIQUE,
            title TEXT,
            company TEXT,
            work_type TEXT,      -- Remote, Hybrid, Onsite
            country TEXT,
            location TEXT,
            job_type TEXT,       -- Full-time, Internship, etc.
            category TEXT,
            salary TEXT,
            date TEXT,
            source TEXT,
            added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Track alerts sent
    c.execute("""
        CREATE TABLE IF NOT EXISTS alerts_sent (
            job_id INTEGER PRIMARY KEY,
            alerted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            alert_type TEXT,
            FOREIGN KEY(job_id) REFERENCES jobs(id)
        )
    """)
    
    conn.commit()
    conn.close()
```

### Key Functions
```python
def insert_job(job_dict):
    """Add job to DB, skip if duplicate (by URL)"""
    try:
        c.execute("""
            INSERT INTO jobs (url, title, company, work_type, ...)
            VALUES (?, ?, ?, ?, ...)
        """, (job_dict["url"], job_dict["title"], ...))
        return True  # New job
    except sqlite3.IntegrityError:
        return False  # Already exists

def get_new_jobs(hours=24):
    """Get jobs added in last N hours that haven't been alerted"""
    c.execute("""
        SELECT j.* FROM jobs j
        LEFT JOIN alerts_sent a ON j.id = a.job_id
        WHERE j.added_at >= datetime('now', '-{} hours')
        AND a.job_id IS NULL
    """, (hours,))
    return c.fetchall()

def export_csv(filename):
    """Export all jobs to CSV"""
    c.execute("SELECT * FROM jobs ORDER BY added_at DESC")
    rows = c.fetchall()
    
    with open(filename, 'w') as f:
        writer = csv.writer(f)
        writer.writerow(["Title", "Company", "Work Type", ...])
        writer.writerows(rows)
```

---

## 4. Alerts (alerts.py) - 200+ Lines

### Telegram
```python
def send_telegram(bot_token, chat_id, message):
    """Send message via Telegram bot"""
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    data = {
        "chat_id": chat_id,
        "text": message,
        "parse_mode": "Markdown"
    }
    r = requests.post(url, json=data)
    return r.status_code == 200

def format_jobs_telegram(jobs):
    """Format jobs as Telegram message"""
    msg = f"*🆕 {len(jobs)} New Jobs Found*\n\n"
    for j in jobs[:10]:
        msg += f"*{j['title']}* @ {j['company']}\n"
        msg += f"🌍 {j['country']} | 💼 {j['work_type']}\n"
        msg += f"💰 {j['salary']}\n"
        msg += f"🔗 {j['url']}\n\n"
    return msg
```

### Email
```python
def send_email(sender, password, recipient, subject, html):
    """Send email via Gmail SMTP"""
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = recipient
    msg.attach(MIMEText(html, "html"))
    
    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
        server.login(sender, password)
        server.sendmail(sender, recipient, msg.as_string())
    
    return True

def format_jobs_email(jobs):
    """Format jobs as HTML email"""
    html = "<html><body>"
    for j in jobs:
        html += f"""
        <div style="border: 1px solid #ddd; padding: 15px;">
            <h3>{j['title']}</h3>
            <p><b>Company:</b> {j['company']}</p>
            <p><b>Salary:</b> {j['salary']}</p>
            <a href="{j['url']}">Apply Now →</a>
        </div>
        """
    html += "</body></html>"
    return html
```

### Slack
```python
def send_slack(webhook_url, message):
    """Send message via Slack webhook"""
    r = requests.post(webhook_url, json={"text": message})
    return r.status_code == 200

def format_jobs_slack(jobs):
    """Format jobs as Slack blocks"""
    blocks = [
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": f"*🆕 {len(jobs)} New Jobs*"
            }
        }
    ]
    for j in jobs[:10]:
        blocks.append({
            "type": "section",
            "text": {"type": "mrkdwn", "text": f"*{j['title']}* @ {j['company']}"},
            "accessory": {
                "type": "button",
                "text": {"type": "plain_text", "text": "Apply"},
                "url": j['url']
            }
        })
    return {"blocks": blocks}
```

---

## 5. Scheduler (scheduler.py) - 200+ Lines

### Main Scheduler Loop
```python
def run_once(config):
    """Fetch jobs once, store in DB, send alerts"""
    print(f"Job Scraper Run: {datetime.now()}")
    
    # 1. Initialize DB
    db.init_db()
    
    # 2. Get enabled sources
    sources = config["sources"]
    enabled = [scrapers[name] for name in sources]
    
    # 3. Fetch jobs
    all_jobs = []
    for scraper in enabled:
        try:
            jobs = scraper()
            all_jobs.extend(jobs)
        except Exception as e:
            print(f"Error: {e}")
    
    # 4. Dedupe
    jobs = rjs.dedupe(all_jobs)
    print(f"Total: {len(jobs)} unique jobs")
    
    # 5. Apply filters
    filtered = []
    for j in jobs:
        if j["work_type"] in config["filters"]["work_type"]:
            if j["country"] in config["filters"]["countries"]:
                if matches_keywords(j, config["filters"]["keywords"]):
                    filtered.append(j)
    
    # 6. Store in DB
    new_count = db.insert_jobs(filtered)
    print(f"New jobs: {new_count}")
    
    # 7. Send alerts
    if config["alerts"]["enabled"] and new_count > 0:
        new_jobs = db.get_new_jobs(hours=24)
        alerts.send_alert(new_jobs, config["alerts"])

def daemon_mode(config):
    """Run continuously on schedule"""
    interval = config["schedule"]["interval_hours"] * 3600
    
    while True:
        run_once(config)
        time.sleep(interval)  # Wait before next run

def print_cron_command(config):
    """Print cron command for background scheduling"""
    interval = config["schedule"]["interval_hours"]
    cron = "0 0,8,16 * * *"  # Every 8 hours
    
    print(f"""
    Add to crontab:
    {cron} cd ~/Desktop/Expts && python scheduler.py >> scheduler.log
    """)
```

---

## 6. 3D Asset Scraper (3d_asset_scraper.py) - 250+ Lines

### Multi-source 3D Scraper
```python
def scrape_upwork():
    """Upwork 3D jobs via RSS"""
    jobs = []
    feeds = [
        "https://www.upwork.com/ab/feed/jobs/rss?q=3d+modeling",
        "https://www.upwork.com/ab/feed/jobs/rss?q=game+development",
        "https://www.upwork.com/ab/feed/jobs/rss?q=blender",
    ]
    
    for url in feeds:
        feed = feedparser.parse(url)
        for entry in feed.entries[:30]:
            title = entry.title
            desc = entry.summary
            
            # Extract skills from description
            skills = extract_skills(title + " " + desc)
            budget = extract_budget(desc)
            
            jobs.append(job("Upwork", title,
                          work_type="Freelance",
                          budget=budget,
                          skills=skills,
                          url=entry.link))
    
    return jobs

def scrape_artstation():
    """ArtStation jobs API"""
    data = get_json("https://www.artstation.com/api/v2/search/jobs")
    jobs = []
    
    for j in data.get("data", []):
        jobs.append(job("ArtStation", j["title"],
                      work_type="Freelance",
                      budget=j.get("budget_type"),
                      skills=", ".join([t["name"] for t in j.get("tags", [])[:5]]),
                      url=f"https://www.artstation.com/jobs/{j['slug']}"))
    
    return jobs
```

---

## Code Statistics

```
Total Lines of Code: 2,000+

Breakdown:
├── remote_job_scraper.py    500 lines
├── app.py                   250 lines
├── scheduler.py             200 lines
├── alerts.py                200 lines
├── 3d_asset_scraper.py      250 lines
├── db.py                    150 lines
└── diagnose.py              150 lines

Total Documentation: 2,500+ lines
(Guides, README, examples, etc.)

Total with Comments: 4,500+ lines
```

---

## Key Design Patterns

### 1. Scraper Pattern
```python
def scraper_function():
    jobs = []
    try:
        data = get_json(API_URL)
        for item in data:
            job_obj = job("Source", item["title"], ...)
            jobs.append(job_obj)
    except Exception:
        pass
    return jobs
```

### 2. Error Handling
```python
try:
    results = scraper()
except Exception as e:
    print(f"Error: {e}")
    # Continue with other scrapers
```

### 3. Caching
```python
@st.cache_data(ttl=3600)  # Cache for 1 hour
def fetch(sources):
    return jobs
```

### 4. Deduplication
```python
seen = set()
for job in jobs:
    key = (title, company, location)
    if key not in seen:
        seen.add(key)
        unique_jobs.append(job)
```

### 5. Filtering Chain
```python
df = df[df["work_type"].isin(work_types)]
df = df[df["country"].str.contains(country)]
df = df[df["title"].str.lower().str.contains(keyword)]
```

---

## What Each Module Does

| Module | Purpose | Key Functions |
|--------|---------|---|
| `remote_job_scraper.py` | Fetch jobs from 17 sources | `scrape_*()`, `dedupe()`, `main()` |
| `app.py` | Interactive web UI | Streamlit components, filters, display |
| `db.py` | Persistent storage | `insert_job()`, `get_new_jobs()`, `export_csv()` |
| `alerts.py` | Notifications | `send_telegram()`, `send_email()`, `send_slack()` |
| `scheduler.py` | Automation | `run_once()`, `daemon_mode()`, `print_cron_command()` |
| `3d_asset_scraper.py` | 3D/freelance jobs | `scrape_upwork()`, `scrape_artstation()`, etc. |
| `diagnose.py` | Troubleshooting | `test_scrapers()`, `check_dependencies()` |

---

**Total: Production-ready job scraping system with 2,000+ lines of Python code + 2,500+ lines of documentation!** 🚀
