"""
Job Finder - Web UI
Run:  streamlit run app.py
(keep this file in the same folder as remote_job_scraper.py)
"""

import pandas as pd
import streamlit as st

import remote_job_scraper as rjs

st.set_page_config(page_title="Job Finder", page_icon="🌍", layout="wide")
st.title("🌍 Job Finder")

SOURCES = {s.__name__.replace("scrape_", ""): s for s in rjs.SCRAPERS}
LABELS = {
    "remotive": "Remotive", "remoteok": "RemoteOK", "himalayas": "Himalayas", "jobicy": "Jobicy",
    "weworkremotely": "We Work Remotely", "arbeitnow": "Arbeitnow (Europe)",
    "adzuna": "Adzuna (search by country)", 
    "internshala": "Internshala (India internships)", "unstop": "Unstop (India freshers)",
    "firstnaukri": "FirstNaukri (India freshers)", "angellist": "AngelList (startups)",
    "devto": "Dev.to (developer jobs)", "upwork": "Upwork (freelance)", "toptal": "Toptal (freelance)",
    "greenhouse": "Greenhouse companies", "lever": "Lever companies", "ashby": "Ashby companies",
}
ADZ_NAME_TO_CODE = {v: k for k, v in rjs.ADZUNA_SUPPORTED.items()}


def split(text):
    return tuple(s.strip() for s in text.split(",") if s.strip())


# ---------------- Sidebar: what to fetch ----------------
with st.sidebar:
    st.header("1 · Sources")
    
    # Group sources by category
    group_remote = ["remotive", "remoteok", "himalayas", "jobicy", "weworkremotely"]
    group_freshers = ["internshala", "unstop", "firstnaukri", "angellist"]
    group_freelance = ["devto", "upwork", "toptal"]
    group_all = ["arbeitnow", "adzuna"]
    group_companies = ["greenhouse", "lever", "ashby"]
    
    selected = []
    
    st.subheader("Remote-only boards")
    for name in group_remote:
        if name in SOURCES and st.checkbox(LABELS.get(name, name), value=True, key=f"src_{name}"):
            selected.append(name)
    
    st.subheader("Freshers & Internships (India focus)")
    for name in group_freshers:
        if name in SOURCES and st.checkbox(LABELS.get(name, name), value=True, key=f"src_{name}"):
            selected.append(name)
    
    st.subheader("Freelance & Developer")
    for name in group_freelance:
        if name in SOURCES and st.checkbox(LABELS.get(name, name), value=False, key=f"src_{name}"):
            selected.append(name)
    
    st.subheader("All jobs (hybrid + onsite)")
    for name in group_all:
        if name in SOURCES and st.checkbox(LABELS.get(name, name), value=False, key=f"src_{name}"):
            selected.append(name)
    
    st.subheader("Company career pages")
    for name in group_companies:
        if name in SOURCES and st.checkbox(LABELS.get(name, name), value=False, key=f"src_{name}"):
            selected.append(name)

    with st.expander("Adzuna settings (jobs by country)", expanded="adzuna" in selected):
        st.caption("Get free keys at developer.adzuna.com")
        adz_id = st.text_input("App ID", value=rjs.ADZUNA_APP_ID, type="password")
        adz_key = st.text_input("App key", value=rjs.ADZUNA_APP_KEY, type="password")
        adz_countries = st.multiselect("Countries", sorted(ADZ_NAME_TO_CODE), default=["India"])
        adz_query = st.text_input("Search for", placeholder="e.g. python developer")
        adz_pages = st.slider("Pages per country (50 jobs each)", 1, 10, 2)

    with st.expander("Company career pages"):
        st.caption("Comma-separated company slugs")
        gh = st.text_input("Greenhouse", ", ".join(rjs.GREENHOUSE_COMPANIES))
        lv = st.text_input("Lever", ", ".join(rjs.LEVER_COMPANIES))
        ab = st.text_input("Ashby", ", ".join(rjs.ASHBY_COMPANIES))

    st.divider()
    st.header("2 · Your Profile")
    
    # Predefined fields for common degrees
    common_fields = [
        "Computer Science / IT", "Cybersecurity", "Data Science", "Web Development",
        "Machine Learning / AI", "Mobile Development", "Cloud Engineering",
        "Business Administration", "Finance / Accounting", "Marketing",
        "Digital Marketing", "HR / People Operations", "Product Management",
        "UX / UI Design", "Graphic Design", "Content Writing",
        "Data Analytics", "Business Analytics", "Project Management",
        "Law", "Optometry", "Pharmacy", "Engineering", "Biotechnology",
    ]
    
    selected_fields = st.multiselect(
        "Your field(s) of study",
        common_fields,
        default=[],
        help="Select your degree/field. Jobs will be matched to these.",
        key="profile_fields"
    )
    
    custom_field = st.text_input(
        "Or enter custom field",
        placeholder="e.g. Aeronautical Engineering, Environmental Science",
        help="If your field isn't listed above",
        key="custom_field"
    )

    run = st.button("🔍 Fetch jobs", type="primary", width="stretch")


@st.cache_data(ttl=3600, show_spinner=False)
def fetch(sources, gh, lv, ab, adz):
    rjs.GREENHOUSE_COMPANIES, rjs.LEVER_COMPANIES, rjs.ASHBY_COMPANIES = list(gh), list(lv), list(ab)
    rjs.ADZUNA_APP_ID, rjs.ADZUNA_APP_KEY, codes, rjs.ADZUNA_QUERY, rjs.ADZUNA_PAGES = adz
    rjs.ADZUNA_COUNTRIES = list(codes)
    jobs, status = [], {}
    for name in sources:
        try:
            results = SOURCES[name]()
            jobs.extend(results)
            status[LABELS.get(name, name)] = f"✅ {len(results)} jobs"
        except Exception as e:
            status[LABELS.get(name, name)] = f"❌ {e}"
    return rjs.dedupe(jobs), status


if run:
    if not selected:
        st.sidebar.warning("Select at least one source.")
    else:
        adz = (adz_id, adz_key, tuple(ADZ_NAME_TO_CODE[c] for c in adz_countries), adz_query, adz_pages)
        with st.spinner("Fetching jobs... this can take a minute"):
            jobs, status = fetch(tuple(selected), split(gh), split(lv), split(ab), adz)
        st.session_state["jobs"], st.session_state["status"] = jobs, status

if "jobs" not in st.session_state:
    st.info("""
    👈 **Getting Started**
    
    1. **Freshers in India?** All India internship + fresher sources are pre-selected.
    2. Click **Fetch jobs** to search across **Internshala, Unstop, FirstNaukri**, and more.
    3. Filter by work type (Remote, Full-time, etc.), country, and keywords.
    4. **Freelancing?** Enable Upwork, Toptal, and Dev.to in the sidebar for project-based work.
    """)
    st.stop()

with st.expander("Source status"):
    for name, msg in st.session_state["status"].items():
        st.write(f"**{name}:** {msg}")

df = pd.DataFrame(st.session_state["jobs"], columns=rjs.FIELDS).fillna("").astype(str)


def options(col, sep):
    s = df[col].str.split(sep).explode().str.strip()
    s = s[(s != "") & (s != "Unspecified")]
    return s.value_counts().index.tolist()


def parts(value, sep):
    return {x.strip() for x in value.split(sep) if x.strip()}


# ---------------- Filters ----------------
st.subheader("Filters")
c1, c2, c3 = st.columns(3)
keyword = c1.text_input("Additional keywords", placeholder="e.g. python, react, UI design")
work_types = c2.multiselect("Work type", ["Remote", "Hybrid", "Onsite"], default=["Remote"])
posted = c3.selectbox("Date posted", ["Any time", "Last 24 hours", "Last 3 days", "Last 7 days", "Last 30 days"])

c4, c5, c6 = st.columns(3)
countries = c4.multiselect("Country / region", options("country", ";"), default=["India"], 
                           placeholder="All countries")
job_types = c5.multiselect("Job type", options("job_type", ","), default=["Full-time", "Internship"],
                           placeholder="All job types")
categories = c6.multiselect("Category", options("category", "|")[:150], placeholder="All categories")

c7, c8 = st.columns(2)
include_ww = c7.checkbox("Also show remote jobs open Worldwide", value=True,
                         help="When you pick countries, also keep remote jobs that accept candidates from anywhere.")
salary_only = c8.checkbox("Only jobs that show salary")

# Build keyword search from user input + profile fields
all_keywords = []
if keyword:
    all_keywords.extend([w.strip().lower() for w in keyword.split(",") if w.strip()])
if selected_fields:
    all_keywords.extend([f.strip().lower() for f in selected_fields])
if custom_field:
    all_keywords.extend([w.strip().lower() for w in custom_field.split(",") if w.strip()])

# Show what you're searching for
if all_keywords:
    st.info(f"🔎 Searching for: **{', '.join(all_keywords)}**")

f = df
if all_keywords:
    text = (f["title"] + " " + f["company"]).str.lower()
    f = f[text.apply(lambda t: any(w in t for w in all_keywords))]
if work_types:
    f = f[f["work_type"].isin(work_types)]
if countries:
    wanted = set(countries) | ({"Worldwide"} if include_ww else set())
    f = f[f["country"].apply(lambda c: bool(wanted & parts(c, ";")))]
if job_types:
    f = f[f["job_type"].apply(lambda t: bool(set(job_types) & parts(t, ",")))]
if categories:
    f = f[f["category"].apply(lambda c: bool(set(categories) & parts(c, "|")))]
if salary_only:
    f = f[f["salary"].str.strip() != ""]
days = {"Last 24 hours": 1, "Last 3 days": 3, "Last 7 days": 7, "Last 30 days": 30}.get(posted)
if days:
    dates = pd.to_datetime(f["date"], errors="coerce", utc=True)
    f = f[dates >= pd.Timestamp.now(tz="UTC") - pd.Timedelta(days=days)]

f = f.sort_values("date", ascending=False)

# ---------------- Results ----------------
counts = f["work_type"].value_counts()
m1, m2, m3, m4 = st.columns(4)
m1.metric("Jobs found", len(f))
m2.metric("Remote", int(counts.get("Remote", 0)))
m3.metric("Hybrid", int(counts.get("Hybrid", 0)))
m4.metric("Onsite", int(counts.get("Onsite", 0)))

if f.empty:
    st.warning("No jobs match these filters. Try removing some.")
    st.stop()

cols = ["title", "company", "work_type", "country", "location", "job_type",
        "category", "salary", "date", "source", "url"]
st.dataframe(
    f[cols],
    width="stretch",
    hide_index=True,
    height=600,
    column_config={
        "title": st.column_config.TextColumn("Title", width="large"),
        "company": "Company",
        "work_type": "Work type",
        "country": "Country / region",
        "location": "Location",
        "job_type": "Job type",
        "category": "Category",
        "salary": "Salary",
        "date": "Posted",
        "source": "Source",
        "url": st.column_config.LinkColumn("Apply", display_text="Open ↗"),
    },
)

st.download_button("⬇️ Download these jobs (CSV)", f[cols].to_csv(index=False).encode("utf-8"),
                   file_name="jobs.csv", mime="text/csv")
